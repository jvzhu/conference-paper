# Aestheticizing the Leaf - IntechOpen submission package

Updated version with selected original East Asian Chinese characters/kanji integrated into the English chapter at first relevant occurrences and in selected tables/references.

## CJK additions
- Chinese: 茶、茶文化、茶经/茶經、茶书、茶具、茶叶、汉字、陆羽、差异化、中介、稳定化、社会化、再语境化
- Japanese kanji: 頼山陽、煎茶、漢詩、十旬花月、茶の湯、煎茶道、茶室、茶壺
- Korean Hanja: 茶禮

## Compilation
The source is configured for XeLaTeX and uses `Noto Serif CJK SC` for Chinese/Japanese/Korean glyphs.

Main source: `Tea_Chapter.tex`
Compiled PDF: `Tea_Chapter.pdf`
